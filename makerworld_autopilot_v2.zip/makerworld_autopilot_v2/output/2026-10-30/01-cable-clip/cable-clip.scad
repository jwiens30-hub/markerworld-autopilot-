
$fn=48;
difference() {
  union() {
    cube([18,11,12], center=true);
    translate([0,0,0]) cylinder(h=12, d=18, center=true);
  }
  cylinder(h=13, d=5, center=true);
  translate([0,0,0]) cube([19,5,13], center=true);
}
