## Kabelclip – parametrischer Entwurf

Ein einfacher Kabelclip für leichte Kabelorganisation. Abmessungen vor dem Einsatz prüfen.

### Druckhinweise
- Zielgerät: Bambu Lab P2S Combo
- Datei: STL-Geometrie; Druckprofil und Material in Bambu Studio selbst festlegen.
- Vor Veröffentlichung slicen und einen realen Testdruck durchführen.

### Hinweise
Nicht für Netzspannung, Zuglast oder sicherheitskritische Anwendungen.

Dies ist ein parametrischer Erstentwurf und kein technisch zertifiziertes Produkt.
