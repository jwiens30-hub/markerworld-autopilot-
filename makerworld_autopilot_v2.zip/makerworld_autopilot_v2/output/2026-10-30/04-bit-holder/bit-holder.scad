
$fn=48;
difference() {
  minkowski() {
    cube([46,16,10],center=true);
    sphere(r=2);
  }
  translate([-20.0,-5.0,-0.5]) cylinder(d=6,h=13,$fn=32);translate([-20.0,5.0,-0.5]) cylinder(d=6,h=13,$fn=32);translate([-10.0,-5.0,-0.5]) cylinder(d=6,h=13,$fn=32);translate([-10.0,5.0,-0.5]) cylinder(d=6,h=13,$fn=32);translate([0.0,-5.0,-0.5]) cylinder(d=6,h=13,$fn=32);translate([0.0,5.0,-0.5]) cylinder(d=6,h=13,$fn=32);translate([10.0,-5.0,-0.5]) cylinder(d=6,h=13,$fn=32);translate([10.0,5.0,-0.5]) cylinder(d=6,h=13,$fn=32);translate([20.0,-5.0,-0.5]) cylinder(d=6,h=13,$fn=32);translate([20.0,5.0,-0.5]) cylinder(d=6,h=13,$fn=32);
}
