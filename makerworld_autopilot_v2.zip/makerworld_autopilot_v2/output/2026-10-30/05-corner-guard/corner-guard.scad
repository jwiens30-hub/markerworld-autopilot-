
$fn=24;
difference() {
  cube([24,24,28],center=false);
  translate([2.4,2.4,2.4])
    cube([24-2.4,24-2.4,28-2.4],center=false);
}
