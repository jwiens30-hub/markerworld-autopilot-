## Kantenschutz-Ecke – parametrischer Entwurf

Einfache Schutz-Ecke für leichte Kanten. Maße und Wandstärke am realen Gegenstand prüfen.

### Druckhinweise
- Zielgerät: Bambu Lab P2S Combo
- Datei: STL-Geometrie; Druckprofil und Material in Bambu Studio selbst festlegen.
- Vor Veröffentlichung slicen und einen realen Testdruck durchführen.

### Hinweise
Kein geprüfter Stoß- oder Personenschutz.

Dies ist ein parametrischer Erstentwurf und kein technisch zertifiziertes Produkt.
