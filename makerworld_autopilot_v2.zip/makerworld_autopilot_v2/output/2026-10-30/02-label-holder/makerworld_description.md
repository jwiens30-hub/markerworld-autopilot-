## Beschriftungsschild-Halter – parametrischer Entwurf

Kleiner Halter für ein selbst erstelltes Beschriftungsschild. Schildmaß vor dem Druck anpassen.

### Druckhinweise
- Zielgerät: Bambu Lab P2S Combo
- Datei: STL-Geometrie; Druckprofil und Material in Bambu Studio selbst festlegen.
- Vor Veröffentlichung slicen und einen realen Testdruck durchführen.

### Hinweise
Nur als leichter Organizer; keine tragende Funktion.

Dies ist ein parametrischer Erstentwurf und kein technisch zertifiziertes Produkt.
