
$fn=32;
union() {
  cube([46,3,3], center=true);
  translate([0,0,10.0])
    difference() {
      cube([46,3,20], center=true);
      translate([0,0,3])
        cube([44,4,14], center=true);
    }
}
