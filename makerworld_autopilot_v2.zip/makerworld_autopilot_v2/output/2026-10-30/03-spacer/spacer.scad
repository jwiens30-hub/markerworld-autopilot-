
$fn=64;
difference() {
  cylinder(d=14, h=8);
  translate([0,0,-0.5]) cylinder(d=5, h=9);
}
