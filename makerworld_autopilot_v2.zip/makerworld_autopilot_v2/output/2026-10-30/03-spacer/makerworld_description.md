## Abstandshalter – parametrischer Entwurf

Ein einfacher Ring-Abstandshalter. Bohrung und Höhe vor Verwendung messen.

### Druckhinweise
- Zielgerät: Bambu Lab P2S Combo
- Datei: STL-Geometrie; Druckprofil und Material in Bambu Studio selbst festlegen.
- Vor Veröffentlichung slicen und einen realen Testdruck durchführen.

### Hinweise
Keine Verwendung an Fahrzeugen, Booten, Maschinen oder sicherheitsrelevanten Verbindungen.

Dies ist ein parametrischer Erstentwurf und kein technisch zertifiziertes Produkt.
