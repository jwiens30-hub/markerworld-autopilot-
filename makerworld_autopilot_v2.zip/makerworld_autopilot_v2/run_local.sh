#!/usr/bin/env bash
set -euo pipefail
python3 src/generate.py
